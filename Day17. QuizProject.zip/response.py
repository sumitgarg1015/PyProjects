class Response:
    def __init__(self):
        self.score = 0

    def response(self, check):
        if check:
            print("You got it right!")
            self.score += 1
        else:
            print("That's wrong.")

    def print_score(self, question_number):
        print(f"Your current score is: {self.score}/{question_number}")
        print("\n")


