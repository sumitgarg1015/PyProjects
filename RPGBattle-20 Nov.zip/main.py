import random
from classes.gameLib import Person, bColors
from classes.game_setup import SetUpGame

# setup Object creation
# setUpobj = setUp_Game()

# setup black magic
black_magic = SetUpGame.setup_blackmagic()

# setup white magic
white_magic = SetUpGame.setup_whitemagic()

# setup spells for player
player_spells = black_magic + white_magic

# setup inventory for player
player_inventory = SetUpGame.setup_items()

# setup Players
player1 = Person("Rob    :", 3200, 400, 600, 600, player_spells, player_inventory)
player2 = Person("Martin :", 3500, 500, 600, 600, player_spells, player_inventory)
player3 = Person("Sukhi  :", 4000, 450, 600, 600, player_spells, player_inventory)

players = [player1, player2, player3]

# setup Enemies
enemy1 = Person("Imp1   :", 1500, 200, 80, 40, black_magic, [])
enemy2 = Person("Megus  :", 12000, 700, 800, 1000, black_magic, [])
enemy3 = Person("Imp2   :", 1500, 200, 80, 400, black_magic, [])

enemies = [enemy1, enemy2, enemy3]

print(bColors.FAIL + bColors.BOLD + "AN ENEMY ATTACKS!!!" + bColors.ENDC)
running = True

defeated_enemies = 0
defeated_players = 0

while running:

    print("*********************************")
    print("\n")
    # ----------------------------------------Player Actions Code----------------------------------------------

    print(bColors.BOLD + bColors.HEADER + bColors.UNDERLINE + "PLAYERS" + bColors.ENDC)
    print("\n")
    print("Name                               HP                               MP        ")

    for player in players:
        player.get_status()

    print("\n")
    print(bColors.BOLD + bColors.HEADER + bColors.UNDERLINE + "ENEMIES" + bColors.ENDC)
    for enemy in enemies:
        if str(enemy.get_name()).__contains__("Imp"):
            enemy.get_imp_status()
        else:
            enemy.get_enemy_status()

    for player in players:
        if player.get_hp() > 0 and defeated_players < 3:
            print("\n")
            player.choose_actions()
            index = 0
            try:
                p_name = player.get_name().split(" ")[0]
                choice = input("Enter your Choice for " + p_name + ":")
                index = int(choice) - 1
                if all([index >= 0, index < 3]):
                    print("You Chose:", player.get_action(index))
                else:
                    print("Wrong Choice Entered!")
                    continue
            except ValueError:
                print("Wrong Choice Entered!")
                continue

            try:
                player.choose_target(enemies)
                choice = input("Choose your Enemy: ")
                enemy_target_index = int(choice) - 1
                if all([index < 0, index >= 3]):
                    print("Wrong Choice Entered!")
                    continue
            except ValueError:
                print("Wrong Choice Entered!")
                continue

            if index == 0:
                power = player.generate_power()
                enemy_target = enemies[enemy_target_index]
                player.get_player_hit_message(enemy_target, power)

            elif index == 1:
                player.choose_spell()
                magic_choice = int(input("Enter your Choice: ")) - 1

                # Get the magic object based on the choice
                player_spell = player.get_magic(magic_choice)

                # Retrieve Name of Magic using Magic object
                spellName = player_spell.get_spell_name()

                # Retrieve Cost of Magic using Magic object
                cost = player_spell.get_spell_mp_cost()

                # Check type of Spell
                spell_type = player_spell.get_magic_type()

                magic_points = player.get_mp()

                # -------Attack/Heal with Player Magic Points---------

                if magic_points < cost:
                    print(bColors.OKBLUE + bColors.BOLD + "\n" + "You do not have sufficient Magic Points to use",
                          bColors.ENDC, spellName)
                    continue
                else:
                    player.reduce_mp(cost)
                    print("You Chose:", spellName)
                    print(p_name, "used", cost, "MP, remaining MP:", bColors.FAIL +
                          str(player.get_mp()) + "/" + str(player.get_max_mp()) + bColors.ENDC)
                    power = player_spell.generate_power()

                    # Check if the Magic is healing or Damaging type
                    if spell_type == 'white':
                        player.heal(power)
                        print(bColors.OKGREEN + "Health Points Added:", power, ", Total Player HP:" +
                              str(player.get_hp()) + bColors.ENDC)
                    else:
                        enemy_target = enemies[enemy_target_index]
                        player.get_player_hit_message(enemy_target, power)

            elif index == 2:
                player.choose_item()
                item_choice = int(input("Choose Item to Use:")) - 1
                item = player.get_item(item_choice)
                item_name = item["item"].get_item_name()
                item_type = item["item"].get_item_type()
                item_prop = item["item"].get_item_prop()
                print("You Chose:", item_name)

                if item["quantity"] == 0:
                    print("No Quantity available for", item_name)
                    continue
                if item_type == "Potion":
                    player.heal(item_prop)
                    print(item_name, "applied!")
                elif item_name == "Elixir":
                    player.heal(item_prop)
                    player.restore_mp()
                    print(player.get_name().split(" ")[0], "HP/MP restored completely")
                elif item_name == "Hi-Elixir":
                    for member in players:
                        member.heal(item_prop)
                        member.restore_mp()
                    print("All Player's HP/MP restored completely")
                elif item_type == "Attack":
                    power = item["item"].generate_power()
                    enemy_target = enemies[enemy_target_index]
                    player.get_player_hit_message(enemy_target, power)

                item["quantity"] -= 1

            if enemies[enemy_target_index].get_hp() == 0:
                print(enemies[enemy_target_index].get_name().split(" ")[0], "Defeated! Cannot take any more Hits")
                defeated_enemies += 1

            # ----------------------------------------Enemy Actions Code----------------------------------------------

            enemy_select = random.randrange(len(enemies))
            enemy = enemies[enemy_select]
            e_name = enemy.get_name().split(" ")[0]
            if enemy.get_hp() > 0 and defeated_enemies < 3:
                enemy_choice = random.randrange(2)
                player_target = random.randrange(len(players))
                player = players[player_target]
                p_name = player.get_name().split(" ")[0]
                print(e_name, "Chose:", enemy.get_action(enemy_choice))

                if enemy_choice == 0:
                    dmg = enemy.generate_power()
                    player.take_damage(dmg)
                    print(e_name, "attacked for", dmg, "points of damage," + p_name + " health remaining:",
                          bColors.FAIL +
                          str(player.get_hp()) + "/" + str(player.get_max_hp())
                          + bColors.ENDC)

                elif enemy_choice == 1:
                    enemy_spell_choice = random.randrange(5)

                    # Get the magic object based on the choice
                    enemy_spell = enemy.get_magic(enemy_spell_choice)

                    # Retrieve Name of Magic using Magic object
                    enemy_spellName = enemy_spell.get_spell_name()

                    # Retrieve Cost of Magic using Magic object
                    enemy_cost = enemy_spell.get_spell_mp_cost()

                    enemy_magic_points = enemy.get_mp()

                    # -------Attack with Enemy Magic Points---------

                    if enemy_magic_points < enemy_cost:
                        print(bColors.OKBLUE + bColors.BOLD + e_name, "cannot choose", enemy_spellName,
                              "due to insufficient magic points", bColors.ENDC + "\n")
                    else:
                        enemy.reduce_mp(enemy_cost)
                        print(e_name, "Chose Magic Type:", enemy_spellName)
                        print(e_name, "used", str(enemy_cost), "MP, remaining MP:",
                              str(enemy.get_mp()) + "/" + str(enemy.get_max_mp()))
                        dmg = enemy_spell.generate_power()
                        player.take_damage(dmg)
                        print(dmg, "points of damage to", p_name, ", HP remaining:", bColors.FAIL +
                              str(player.get_hp()) + "/" + str(player.get_max_hp())
                              + bColors.ENDC)

                if player.get_hp() == 0:
                    defeated_players += 1
                    print(p_name, "Defeated! Cannot take more Hits")
            elif defeated_enemies == 3:
                print("Game Over! You Won")
                running = False

        elif defeated_players == 3:
            print("Game Over! Enemies Won")
            running = False
