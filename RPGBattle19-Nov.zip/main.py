import random
from classes.gameLib import Person, bColors
from classes.magic import Spell
from classes.inventory import Items

# black magic
fire = Spell("Fire", 100, 700, "black")
thunder = Spell("Thunder", 120, 900, "black")
blizzard = Spell("Blizzard", 110, 800, "black")
meteor = Spell("Meteor", 150, 1100, "black")
quake = Spell("Quake", 150, 1100, "black")

# white magic

cure = Spell("Cure", 150, 1000, "white")

# Items

# name, itype, description, prop
potion = Items("Potion", "Potion", "Heal 50 HP", 500)
hiPotion = Items("Hi-Potion", "Potion", "Heal 100 HP", 1000)
superPotion = Items("Super-Potion", "Potion", "Heal 300 HP", 3000)
elixir = Items("Elixir", "Elixir", "Restore HP/MP for 1 Member", 9999)
hiElixir = Items("Hi-Elixir", "Elixir", "Restore HP/MP for all Members", 9999)
grenade = Items("Grenade", "Attack", "Attacks Enemy with 400 points", 1400)

# hp, mp, atk, df, magic
player_spells = [fire, thunder, blizzard, meteor, quake, cure]
player_inventory = [{"item": potion, "quantity": 5},
                    {"item": hiPotion, "quantity": 3},
                    {"item": superPotion, "quantity": 2},
                    {"item": elixir, "quantity": 1},
                    {"item": hiElixir, "quantity": 1},
                    {"item": grenade, "quantity": 3}]

player1 = Person("Rob   :", 3200, 400, 600, 600, player_spells, player_inventory)
player2 = Person("Martin:", 3500, 500, 600, 600, player_spells, player_inventory)
player3 = Person("Sukhi :", 4000, 450, 600, 600, player_spells, player_inventory)

players = [player1, player2, player3]

enemy1 = Person("Imp   :", 1500, 100, 80, 200, [fire, thunder, blizzard, meteor, quake], [])
enemy2 = Person("Megus :", 12000, 700, 800, 800, [fire, thunder, blizzard, meteor, quake], [])
enemy3 = Person("Imp   :", 1500, 100, 80, 200, [fire, thunder, blizzard, meteor, quake], [])

enemies = [enemy1, enemy2, enemy3]
print("\n")

print(bColors.FAIL + bColors.BOLD + "AN ENEMY ATTACKS!!!" + bColors.ENDC)
print("\n")
running = True

while running:

    print("*********************************")
    print("\n")
    # ----------------------------------------Player Actions Code----------------------------------------------
    print("Name                               HP                               MP        ")

    for player in players:
        player.get_status()

    print("\n")
    for enemy in enemies:
        enemy.get_enemy_status()

    print("\n")

    for player in players:
        player.choose_actions()
        index = 0
        try:
            choice = input("Enter your Choice for " + player.get_name())
            index = int(choice) - 1
            if all([index >= 0, index < 3]):
                print("You Chose:", player.get_action(index))
            else:
                print("Wrong Choice Entered!")
                continue
        except ValueError:
            print("Wrong Choice Entered!")
            continue

        try:
            player.choose_target(enemies)
            choice = input("Choose your Enemy: ")
            enemy_target = int(choice) - 1
            if all([index < 0, index >= 3]):
                print("Wrong Choice Entered!")
                continue
        except ValueError:
            print("Wrong Choice Entered!")
            continue

        if index == 0:
            dmg = player.generate_damage()
            enemies[enemy_target].take_damage(dmg)
            print(bColors.OKGREEN + "You attacked for", dmg, "points of damage,", "Enemy Health remaining:",
                  str(enemy.get_hp()) + "/" + str(enemy.get_max_hp()) + bColors.ENDC)

        elif index == 1:
            player.choose_spell()
            magic_choice = int(input("Enter your Choice: ")) - 1

            # Get the magic object based on the choice
            player_spell = player.get_magic(magic_choice)

            # Retrieve Name of Magic using Magic object
            spellName = player_spell.get_spell_name()

            # Retrieve Cost of Magic using Magic object
            cost = player_spell.get_spell_mp_cost()

            # Check type of Spell
            spell_type = player_spell.get_magic_type()

            magic_points = player.get_mp()

            # -------Attack/Heal with Player Magic Points---------

            if magic_points < cost:
                print(bColors.OKBLUE + bColors.BOLD + "\n" + "You do not have sufficient Magic Points to use",
                      bColors.ENDC, spellName)
                continue
            else:
                player.reduce_mp(cost)
                print("You Chose:", spellName)
                print("You used", cost, "magic points, remaining MP:", bColors.FAIL +
                      str(player.get_mp()) + "/" + str(player.get_max_mp()) + bColors.ENDC)
                power = player_spell.generate_damage()

                # Check if the Magic is healing or Damaging type
                if spell_type == 'white':
                    player.heal(power)
                    print(bColors.OKGREEN + "Health Points Added:", power, ", Total Player HP:" +
                          str(player.get_hp()) + bColors.ENDC)
                else:
                    enemies[enemy_target].take_damage(power)
                    print(enemies[enemy_target].get_name(), "is attacked with", power, "points" + bColors.OKGREEN +
                          str(enemies[enemy_target].get_hp()) + "/" + str(enemies[enemy_target].get_max_hp())
                          + bColors.ENDC)
        elif index == 2:
            player.choose_item()
            item_choice = int(input("Choose Item to Use:")) - 1
            item = player.get_item(item_choice)
            item_name = item["item"].get_item_name()
            item_type = item["item"].get_item_type()
            item_prop = item["item"].get_item_prop()
            print("You Chose:", item_name)

            if item["quantity"] == 0:
                print("No Quantity available for", item_name)
                continue
            if item_type == "Potion":
                player.heal(item_prop)
                print(item_name, "applied!")
            elif item_name == "Elixir":
                player.heal(item_prop)
                player.restore_mp()
                print("Player's HP/MP restored completely")
            elif item_name == "Hi-Elixir":
                for member in players:
                    member.heal(item_prop)
                    member.restore_mp()
                print("All Player's HP/MP restored completely")
            elif item_type == "Attack":
                enemies[enemy_target].take_damage(item_prop)
                print(enemies[enemy_target].get_name(), "is attacked with", power, "points" + bColors.OKGREEN +
                      str(enemies[enemy_target].get_hp()) + "/" + str(enemies[enemy_target].get_max_hp())
                      + bColors.ENDC)
            item["quantity"] -= 1

    # ----------------------------------------Enemy Actions Code----------------------------------------------

        enemy_attack = random.randrange(len(enemies))
        enemy = enemies[enemy_attack]
        if enemy.get_hp() > 0:
            enemy_choice = random.randrange(2)
            player_target = random.randrange(len(players))

            print("Enemy Chose:", enemy.get_action(enemy_choice))
            if enemy_choice == 0:
                dmg = enemy.generate_damage()
                players[player_target].take_damage(dmg)
                print("Enemy attacked for", dmg, "points of damage, Player health remaining:", bColors.FAIL +
                      str(player.get_hp()) + "/" + str(player.get_max_hp()) + bColors.ENDC)

            elif enemy_choice == 1:
                enemy_spell_choice = random.randrange(5)

                # Get the magic object based on the choice
                enemy_spell = enemy.get_magic(enemy_spell_choice)

                # Retrieve Name of Magic using Magic object
                enemy_spellName = enemy_spell.get_spell_name()

                # Retrieve Cost of Magic using Magic object
                enemy_cost = enemy_spell.get_spell_mp_cost()

                enemy_magic_points = enemy.get_mp()

                # -------Attack with Enemy Magic Points---------

                if enemy_magic_points < enemy_cost:
                    print(bColors.OKBLUE + bColors.BOLD + "Enemy cannot choose", enemy_spellName,
                          "due to insufficient magic points", bColors.ENDC + "\n")
                else:
                    enemy.reduce_mp(enemy_cost)
                    print("Enemy Chose Magic Type:", enemy_spellName)
                    print("Enemy used", enemy_cost, ", magic points remaining:",
                          str(enemy.get_mp()) + "/" + str(enemy.get_max_mp()))
                    dmg = enemy_spell.generate_damage()
                    players[player_target].take_damage(dmg)
                    print(dmg, "points of damage to", player.name, "HP remaining:", bColors.FAIL +
                          str(player.get_hp()) + "/" + str(player.get_max_hp()) + bColors.ENDC)

    # -----------------------------------------------Who Wins!!!----------------------------------------------

        if enemy.get_hp() == 0:
            print("Game Over! You Won")
            running = False
        elif player.get_hp() == 0:
            print("Gave Over! Enemy Won")
            running = False
