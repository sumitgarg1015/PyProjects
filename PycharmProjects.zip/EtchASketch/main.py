import turtle as t

pointer = t.Turtle()
screen = t.Screen()

pointer.speed(3)


def move_forward():
    pointer.forward(10)


def move_backward():
    pointer.backward(10)


def counter_clockwise():
    pointer.setheading(pointer.heading() + 5)


def clockwise():
    pointer.setheading(pointer.heading() - 5)


def reset():
    screen.clear()
    pointer.penup()
    pointer.home()
    pointer.pendown()


screen.listen()

screen.onkeypress(key="w", fun=move_forward)
screen.onkeypress(key="s", fun=move_backward)
screen.onkeypress(key="a", fun=counter_clockwise)
screen.onkeypress(key="d", fun=clockwise)
screen.onkey(key="c", fun=reset)

screen.exitonclick()
