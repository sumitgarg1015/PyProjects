import colorgram as cg

colors = cg.extract("palette.JPG", 6)
colors_list = []
for color in colors:
    r, g, b = color.rgb
    colors_list.append((r, g, b))

print(colors_list)
