from data import question_data
from question_model import Questions
from response import Response

my_response = Response()

for i in range(1, len(question_data)+1):
    question = question_data[i-1]
    my_question = Questions(question["question"], question["correct_answer"])

    my_question.ask_question(i)
    my_response.response(my_question.check_answer())
    my_question.print_answer()

    my_response.print_score(i)

print("You have completed the quiz!")
print(f"Your final score is {my_response.score}/{i}")
