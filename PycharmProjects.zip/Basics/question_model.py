class Questions:
    def __init__(self, question, answer):
        self.question = question
        self.answer = answer
        self.user_answer = ''

    def ask_question(self, number):
        self.user_answer = input(f"Q.{number}: {self.question} (True/False)?: ").title()

    def check_answer(self):
        if self.user_answer == self.answer:
            return True
        else:
            return False

    def print_answer(self):
        print(f"The correct answer was: {self.answer}")
