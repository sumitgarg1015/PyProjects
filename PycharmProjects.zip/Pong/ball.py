from turtle import Turtle


class Ball(Turtle):

    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.color("yellow")
        self.shapesize(0.7)
        self.penup()
        self.x_cor = 10
        self.y_cor = 10
        self.move_speed = 0.1

    def move(self):
        self.goto(self.xcor() + self.x_cor, self.ycor() + self.y_cor)

    def y_bounce(self):
        self.y_cor *= -1

    def x_bounce(self):
        self.x_cor *= -1
        self.move_speed *= 0.9

    def reset_ball(self):
        self.home()
        self.x_bounce()
        self.move_speed = 0.1



