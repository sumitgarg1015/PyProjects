from players import Paddle
from turtle import Screen
from ball import Ball
from score import Scoreboard
import time

screen = Screen()

screen.title("Pong Game")
screen.setup(800, 600)
screen.bgcolor("black")
screen.tracer(0)
l_paddle = Paddle((-360, 0))
r_paddle = Paddle((360, 0))

screen.listen()
screen.onkeypress(l_paddle.up, "w")
screen.onkeypress(l_paddle.down, "s")
screen.onkeypress(r_paddle.up, "Up")
screen.onkeypress(r_paddle.down, "Down")

ball = Ball()
score = Scoreboard()
game_is_on = True

while game_is_on:
    screen.update()
    time.sleep(ball.move_speed)
    ball.move()

    #Detect collision with the wall or paddle

    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.y_bounce()

    if ball.distance(r_paddle) < 30 and ball.xcor() > 330 or ball.distance(l_paddle) < 30 and ball.xcor() < -330:
        ball.x_bounce()

    # What if ball misses

    if ball.xcor() > 380:
        score.update_l_score()
        ball.reset_ball()

    if ball.xcor() < -380:
        score.update_r_score()
        ball.reset_ball()

screen.exitonclick()
