from turtle import Turtle


class Paddle(Turtle):

    def __init__(self, position):
        super().__init__()
        self.shape("square")
        self.penup()
        self.color("white")
        self.shapesize(5, 0.8)
        self.goto(position)

    def up(self):
        if self.ycor() < 230:
            self.goto(self.xcor(), self.ycor()+20)

    def down(self):
        if self.ycor() > -230:
            self.goto(self.xcor(), self.ycor()-20)
