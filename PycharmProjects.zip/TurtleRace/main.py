import random
import turtle
import turtle as t

screen = t.Screen()
screen.setup(width=700, height=500)
user_choice = t.textinput(title="Bet Your Choice!", prompt="Which Turtle Color will win the Race? ").capitalize()
screen.addshape("Finish Line", "Rectangle")

tplayers = []
turtle.colormode(255)
init_x = -300
init_y = 150
finish_line = 300.00
colors = ['Violet', 'Indigo', 'Red', 'Green', 'Yellow', 'Blue']


def generate_color(a):
    return colors[a]


def move_player(pointer):
    x = random.randint(0, 9)
    pointer.forward(x)


def init_player(x, y):
    player = t.Turtle(shape="turtle")
    player.penup()
    player.color(generate_color(i))
    player.goto(x, y)
    return player


for i in range(6):
    tplayers.append(init_player(init_x, init_y))
    init_y -= 50

is_race_on = True

while is_race_on:
    for tplayer in tplayers:
        move_player(tplayer)
        if tplayer.xcor() >= finish_line:
            winning_color = tplayer.pencolor()
            is_race_on = False
            break

if winning_color == user_choice:
    print(f"Your Won. The {winning_color} Turtle is the Winner")
else:
    print(f"Your {user_choice} Turtle Lost. The {winning_color} Turtle is the Winner")

screen.exitonclick()
