from turtle import Screen
from player import Player
from car import Car
from score import Score
import time
import random

screen = Screen()

screen.title("Turtle Crossing")
screen.bgcolor("white")
screen.setup(600, 600)
screen.tracer(0)
screen.colormode(255)

player = Player()
game_is_on = True

screen.listen()
screen.onkeypress(player.up, "Up")


def generate_color():
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    color = (r, g, b)
    return color


car = Car()
score = Score()

while game_is_on:
    time.sleep(0.1)
    screen.update()

    car.create_car(generate_color())

    if player.ycor() > 300:
        player.go_to_start()
        car.increase_speed()
        score.update_level()

    if car.check_collision(player):
        game_is_on = False
        score.game_over()

screen.exitonclick()
