from turtle import Turtle

LEVEL_POSITION = (-280, 250)
FONT = ("Calibri", 16, "normal")


class Score(Turtle):

    def __init__(self):
        super().__init__()
        self.level_count = 0
        self.penup()
        self.color("blue")
        self.hideturtle()
        self.goto(LEVEL_POSITION)
        self.level()

    def game_over(self):
        self.home()
        self.color("red")
        self.write("Game Over!", align="center", font=FONT)

    def update_level(self):
        self.level_count += 1
        self.level()

    def level(self):
        self.clear()
        self.write(f"Level: {self.level_count}", align="left", font=FONT)
