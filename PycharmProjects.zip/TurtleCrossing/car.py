from turtle import Turtle
import random


class Car:

    def __init__(self):
        self.cars = []
        self.distance = 5

    def create_car(self, color):
        num = random.randint(1, 6)
        if num == 1:
            car = Turtle("square")
            car.shapesize(1, 2)
            car.color(color)
            car.penup()
            x = 300
            y = random.randint(-250, 250)
            car.goto(x, y)
            self.cars.append(car)

        self.move_car()

    def move_car(self):
        for car in self.cars:
            # To move the cars from right to left since their head is pointed towards right
            car.backward(self.distance)

    def check_collision(self, player):
        for car in self.cars:
            if car.distance(player) < 20:
                return True

        return False

    def increase_speed(self):
        self.distance += 5
