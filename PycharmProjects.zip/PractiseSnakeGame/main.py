from snake import Snake
from turtle import Screen
from food import Food
from score import Scoreboard
import time

screen = Screen()
screen.setup(600, 600)
screen.bgcolor("black")
screen.tracer(0)

snake = Snake()

screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")

food = Food()
score = Scoreboard()
game_is_on = True

while game_is_on:
    screen.update()
    time.sleep(0.07)
    # Move the snake while game is on
    snake.move()

    # Change the Food location if eaten
    if snake.head.distance(food) < 10:
        food.relocate()
        snake.extend()
        score.increase()

    # Check if the Snake hit the wall
    if snake.head.xcor() < -290 or snake.head.xcor() > 290 or snake.head.ycor() < -290 or snake.head.ycor() > 290:
        game_is_on = False
        score.game_over()

    # Check if the Snake touches its own tail
    for segment in snake.segments[1:]:
        if snake.head.distance(segment) < 8:
            game_is_on = False
            score.game_over()

screen.exitonclick()
