from turtle import Turtle

STARTING_SIZE = 3
Y = 0
UP = 90
DOWN = 270
RIGHT = 0
LEFT = 180


class Snake:

    def __init__(self):
        self.segments = []
        self.x = 0
        self.create_snake()
        self.head = self.segments[0]

    def create_snake(self):
        for i in range(STARTING_SIZE):
            self.add_segment((self.x, Y))
            self.x -= 13

    def add_segment(self, position):
        dot = Turtle()
        dot.penup()
        dot.shape("square")
        dot.color("white")
        dot.shapesize(0.5)
        dot.goto(position)
        self.segments.append(dot)

    def move(self):
        for i in range(len(self.segments)-1, 0, -1):
            x_cor = self.segments[i - 1].xcor()
            y_cor = self.segments[i - 1].ycor()
            self.segments[i].goto(x_cor, y_cor)
        self.head.forward(10)

    def extend(self):
        self.add_segment(self.segments[-1].position())

    def up(self):
        if self.head.heading() != DOWN:
            self.head.setheading(UP)

    def down(self):
        if self.head.heading() != UP:
            self.head.setheading(DOWN)

    def left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(RIGHT)
