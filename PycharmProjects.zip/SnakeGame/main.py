from turtle import Screen
from Food import Food
from Snake import Snake
from scoreboard import Scoreboard
import time

screen = Screen()
screen.title("Snake Game")
screen.bgcolor("black")
screen.setup(width=600, height=600)
screen.tracer(0)

snake = Snake()
screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")

game_is_on = True
food = Food()
scoreboard = Scoreboard()


def is_game_over(head):
    x_cor = head.xcor()
    y_cor = head.ycor()
    if x_cor > 295 or x_cor < -295 or y_cor > 295 or y_cor < -295:
        scoreboard.gave_over()
        return False
    else:
        return True


while game_is_on:
    screen.update()
    time.sleep(0.07)
    snake.move()
    if snake.head.distance(food) < 8:
        food.relocate()
        scoreboard.increase_score()
        snake.extend()

    game_is_on = is_game_over(snake.head)

    for dot in snake.pointers[1:]:
        if snake.head.distance(dot) < 8:
            scoreboard.gave_over()
            game_is_on = False

screen.exitonclick()
