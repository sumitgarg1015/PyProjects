import turtle as t
INITIAL_SIZE = 3
UP = 90
DOWN = 270
RIGHT = 0
LEFT = 180
Y = 0


class Snake:

    def __init__(self):
        self.pointers = []
        self.x = 0
        self.create_snake()
        self.head = self.pointers[0]

    def create_snake(self):
        for i in range(INITIAL_SIZE):
            self.add_tail((self.x, Y))
            self.x -= 11

    def add_tail(self, position):
        pointer = t.Turtle(shape="square")
        pointer.penup()
        pointer.color("white")
        pointer.shapesize(0.5)
        pointer.goto(position)
        self.pointers.append(pointer)

    def extend(self):
        self.add_tail(self.pointers[-1].position())

    def move(self):
        for i in range(len(self.pointers) - 1, 0, -1):
            x_cor = self.pointers[i - 1].xcor()
            y_cor = self.pointers[i - 1].ycor()
            self.pointers[i].goto(x_cor, y_cor)
        self.head.forward(10)

    def up(self):
        if self.head.heading() != DOWN:
            self.head.setheading(90)

    def down(self):
        if self.head.heading() != UP:
            self.head.setheading(270)

    def left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(180)

    def right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(0)
