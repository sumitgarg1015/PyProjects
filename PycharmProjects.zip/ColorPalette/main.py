# import turtle as t
# import random
#
# pointer = t.Turtle()
# screen = t.Screen()
#
#
# def generate_color():
#     r = random.randint(0, 255)
#     g = random.randint(0, 255)
#     b = random.randint(0, 255)
#     color = (r, g, b)
#     return color
#
#
# def set_x_y(x_pos, y_pos):
#     pointer.setx(x_pos)
#     pointer.sety(y_pos)
#
# x = -150
# y = -100
# size = 10
# gap = size * 4
# pointer.speed("fastest")
# t.colormode(255)
# pointer.penup()
# pointer.hideturtle()
#
# for _ in range(10):
#     set_x_y(x, y)
#     for _ in range(10):
#         pointer.dot(size, generate_color())
#         x += gap
#         set_x_y(x, y)
#
#     x = -150
#     y += gap
#
# screen.exitonclick()

import turtle as t
import random

pointer = t.Turtle()
screen = t.Screen()


def generate_color():
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    color = (r, g, b)
    return color


def set_x_y(x_pos, y_pos):
    pointer.penup()
    pointer.setx(x_pos)
    pointer.sety(y_pos)
    pointer.pendown()


x = -200
y = -150
radius = 7
gap = radius * 6
pointer.speed("fastest")
t.colormode(255)
pointer.hideturtle()

for _ in range(10):
    new_x = x
    set_x_y(new_x, y)
    for _ in range(10):
        pointer.color(generate_color())
        pointer.begin_fill()
        pointer.circle(radius)
        pointer.end_fill()
        new_x += gap
        set_x_y(new_x, y)

    y += gap

screen.exitonclick()
