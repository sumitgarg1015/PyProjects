import turtle as t
from data import *
import random

pointer = t.Turtle()
pointer.shape("turtle")

# for _ in range(4*10):
#     pointer.penup()
#     pointer.forward(10)
#     pointer.pendown()
#     if _ % 100 == 0:
#         pointer.right(90)

# print(my_turtle.position())

# for _ in range(4):
#     for _ in range(10):
#         pointer.forward(10)
#         pointer.penup()
#         pointer.forward(10)
#         pointer.pendown()
#     pointer.left(90)


# class Shapes:
#     def __init__(self, tlines, tcolors):
#         self.sides = tlines
#         self.colors = tcolors
#         self.x = -100
#         self.y = 200
#         self.length = 100
#         self.angle = 0
#
#     def set_configuration(self):
#         pointer.penup()
#         pointer.setx(self.x)
#         pointer.sety(self.y)
#         pointer.pendown()
#         pointer.speed(2)
#
#     def draw_shape(self, lines, color):
#         self.angle = 360/lines
#         pointer.color(color)
#         for _ in range(lines):
#             pointer.forward(self.length)
#             pointer.right(self.angle)
#
#
# my_shapes = Shapes(sides, colors)
#
# for side in sides:
#     my_shapes.set_configuration()
#     my_shapes.draw_shape(side, random.choice(colors))


# class Random_Walk:
#
#     def __init__(self):
#         self.angles = [0, 90, 180, 270]
#         pointer.width(7)
#         pointer.speed(0)
#
#     def walk(self):
#         # r = random.randint(0, 255)
#         # g = random.randint(0, 255)
#         # b = random.randint(0, 255)
#         r = random.random()
#         g = random.random()
#         b = random.random()
#
#         set_color = (r, g, b)
#         pointer.color(set_color)
#         angle = random.choice(self.angles)
#         pointer.setheading(angle)
#         pointer.forward(20)
#
# t.colormode(1)
# my_screen = t.Screen()
#
# my_walk = Random_Walk()
#
# for _ in range(300):
#     my_walk.walk()
#
#

#
# pointer.speed(0)

class DrawSpirograph:

    def __init__(self):
        self.degree = 5
        self.no_of_circles = int(360 / self.degree)
        self.color = ()
        self.r = 0
        self.g = 0
        self.b = 0

    def generate_color(self):
        self.r = random.randint(0, 255)
        self.g = random.randint(0, 255)
        self.b = random.randint(0, 255)
        self.color = (self.r, self.g, self.b)
        return self.color

    def set_config(self):
        t.colormode(255)
        pointer.speed(0)


spirograph = DrawSpirograph()
spirograph.set_config()

for degree in range(spirograph.no_of_circles):
    pointer.color(spirograph.generate_color())
    pointer.circle(100)
    pointer.left(spirograph.degree)

my_screen = t.Screen()
my_screen.exitonclick()
