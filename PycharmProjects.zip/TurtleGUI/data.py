sides = [3, 4, 5, 6, 7, 8, 9, 10]
colors = ["LightBlue", "CadetBlue", "MediumVioletRed", "MistyRose", "moccasin", "purple",
          "chocolate", "green"]
