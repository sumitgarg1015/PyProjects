import random


class bColors:

    HEADER = '\033[35m'
    OKBLUE = '\033[34m'
    OKGREEN = '\033[32m'
    WARNING = '\033[33m'
    FAIL = '\033[31m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


class Person:

    def __init__(self, name, hp, mp, atk, df, magic, items):
        self.hp = hp
        self.maxHp = hp
        self.mp = mp
        self.maxMp = mp
        self.atkL = atk - 10
        self.atkH = atk + 10
        self.df = df
        self.magic = magic
        self.items = items
        self.name = name
        self.actions = ["Attack", "Magic", "Items"]

    def generate_power(self):
        return random.randrange(self.atkL, self.atkH)

    def take_damage(self, dmg):
        self.hp -= dmg
        if self.hp < 0:
            self.hp = 0
        return self.hp

    def get_magic(self, i):
        return self.magic[i]

    def get_item(self, i):
        return self.items[i]

    def get_hp(self):
        return self.hp

    def heal(self, addhp):
        self.hp += addhp
        if self.hp > self.maxHp:
            self.hp = self.maxHp

    def get_max_hp(self):
        return self.maxHp

    def get_mp(self):
        return self.mp

    def restore_mp(self):
        self.mp = self.maxMp

    def get_max_mp(self):
        return self.maxMp

    def reduce_mp(self, cost):
        self.mp -= cost

    def get_action(self, i):
        return self.actions[i]

    def get_player_hit_message(self, enemy, power):
        p_name = self.name.split(" ")[0]
        e_name = enemy.name.split(" ")[0]
        enemy.take_damage(power)
        print(bColors.OKGREEN + p_name + " attacked for", power, "points of damage,", e_name, "Health remaining:",
              str(enemy.get_hp()) + "/" + str(enemy.get_max_hp()) + bColors.ENDC)

    def choose_actions(self):
        i = 1
        print(bColors.HEADER + "ACTIONS:" + bColors.ENDC)
        for item in self.actions:
            print("    " + str(i), ":", item)
            i += 1

    def choose_spell(self):
        i = 1
        print(bColors.HEADER + "SPELLS:" + bColors.ENDC)
        for spell in self.magic:
            print("    " + str(i), ":", spell.get_spell_name(), " (Cost=" + str(spell.get_spell_mp_cost()) + ")")
            i += 1

    def choose_enemy_spell(self):


    def choose_item(self):
        i = 1
        print(bColors.HEADER + "ITEMS:" + bColors.ENDC)
        for item in self.items:
            print("    " + str(i), ":", item["item"].get_item_name(), " ("
                  + item["item"].get_item_description() + ")", "(x" + str(item["quantity"]) + ")")
            i += 1

    def get_enemy_status(self):
        hp_bar = ""
        bar_ticks = self.hp / self.maxHp * 50

        while bar_ticks > 0:
            hp_bar += "▌"
            bar_ticks -= 1

        while len(hp_bar) < 50:
            hp_bar += " "

        mp_bar = ""
        mp_bar_ticks = self.mp / self.maxMp * 25

        while mp_bar_ticks > 0:
            mp_bar += "▌"
            mp_bar_ticks -= 1

        while len(mp_bar) < 25:
            mp_bar += " "

        str_Hp = str(self.hp)
        str_Mp = str(self.mp)

        while len(str_Hp) < 4:
            str_Hp = " " + str_Hp

        while len(str_Mp) < 3:
            str_Mp = " " + str_Mp

        print("                       __________________________________________________            ________________"
              "_________ ")

        print(self.name + "   " + str_Hp + "/" + str(self.maxHp) + "|" + bColors.BOLD
              + bColors.FAIL + hp_bar + bColors.ENDC + "|  " + str_Mp +
              "/" + str(self.maxMp) + " |" + bColors.BOLD + bColors.WARNING + mp_bar + bColors.ENDC
              + "|")

    def get_status(self):

        hp_bar = ""
        bar_ticks = self.hp / self.maxHp * 25

        while bar_ticks > 0:
            hp_bar += "▌"
            bar_ticks -= 1

        while len(hp_bar) < 25:
            hp_bar += " "

        mp_bar = ""
        mp_bar_ticks = self.mp/self.maxMp * 15

        while mp_bar_ticks > 0:
            mp_bar += "▌"
            mp_bar_ticks -= 1

        while len(mp_bar) < 15:
            mp_bar += " "

        str_Hp = str(self.hp)
        str_Mp = str(self.mp)

        while len(str_Hp) < 4:
            str_Hp = " " + str_Hp

        while len(str_Mp) < 3:
            str_Mp = " " + str_Mp

        print("                       _________________________            _______________ ")
        print(self.name + "     " + str_Hp + "/" + str(self.maxHp) + "|" + bColors.BOLD
              + bColors.OKGREEN + hp_bar + bColors.ENDC + "|  " + str_Mp +
              "/" + str(self.maxMp) + " |" + bColors.BOLD + bColors.OKBLUE + mp_bar + bColors.ENDC
              + "|")

    def get_imp_status(self):

        hp_bar = ""
        bar_ticks = self.hp / self.maxHp * 10

        while bar_ticks > 0:
            hp_bar += "▌"
            bar_ticks -= 1

        while len(hp_bar) < 10:
            hp_bar += " "

        mp_bar = ""
        mp_bar_ticks = self.mp/self.maxMp * 8

        while mp_bar_ticks > 0:
            mp_bar += "▌"
            mp_bar_ticks -= 1

        while len(mp_bar) < 8:
            mp_bar += " "

        str_Hp = str(self.hp)
        str_Mp = str(self.mp)

        while len(str_Hp) < 4:
            str_Hp = " " + str_Hp

        while len(str_Mp) < 3:
            str_Mp = " " + str_Mp

        print("                       __________            ________")
        print(self.name + "     " + str_Hp + "/" + str(self.maxHp) + "|" + bColors.BOLD
              + bColors.FAIL + hp_bar + bColors.ENDC + "|  " + str_Mp +
              "/" + str(self.maxMp) + " |" + bColors.BOLD + bColors.WARNING + mp_bar + bColors.ENDC
              + "|")

    def get_name(self):
        return self.name

    def choose_target(self, enemies):
        print(bColors.BOLD + bColors.FAIL + "TARGET:" + bColors.ENDC)
        i = 1
        for enemy in enemies:
            print("    " + str(i) + ". " + enemy.name)
            i += 1
