from classes.gameLib import Person, bColors
from classes.magic import Spell
from classes.inventory import Items


class SetUpGame:

    @staticmethod
    def setup_blackmagic():
        fire = Spell("Fire", 100, 700, "black")
        thunder = Spell("Thunder", 120, 900, "black")
        blizzard = Spell("Blizzard", 110, 800, "black")
        meteor = Spell("Meteor", 150, 1100, "black")
        quake = Spell("Quake", 150, 1100, "black")

        return [fire, thunder, blizzard, meteor, quake]

    @staticmethod
    def setup_whitemagic():
        cure = Spell("Cure", 150, 1000, "white")
        return [cure]

    @staticmethod
    def setup_items():
        potion = Items("Potion", "Potion", "Heal 50 HP", 500)
        hipotion = Items("Hi-Potion", "Potion", "Heal 100 HP", 1000)
        superpotion = Items("Super-Potion", "Potion", "Heal 300 HP", 3000)
        elixir = Items("Elixir", "Elixir", "Restore HP/MP for 1 Member", 9999)
        hielixir = Items("Hi-Elixir", "Elixir", "Restore HP/MP for all Members", 9999)
        grenade = Items("Grenade", "Attack", "Attacks Enemy with 400 points", 1400)

        player_inventory = [{"item": potion, "quantity": 5},
                            {"item": hipotion, "quantity": 3},
                            {"item": superpotion, "quantity": 2},
                            {"item": elixir, "quantity": 1},
                            {"item": hielixir, "quantity": 1},
                            {"item": grenade, "quantity": 3}]

        return player_inventory


