import random


class Items:

    def __init__(self, name, itype, description, prop):
        self.name = name
        self.iType = itype
        self.description = description
        self.prop = prop

    def get_item_name(self):
        return self.name

    def get_item_type(self):
        return self.iType

    def get_item_description(self):
        return self.description

    def get_item_prop(self):
        return self.prop

    def generate_power(self):
        dLow = self.prop - 100
        dHigh = self.prop + 100
        return random.randrange(dLow, dHigh)


