import random
from classes.gameLib import Person, bColors
from classes.magic import Spell

# black magic
fire = Spell("Fire", 10, 100, "black")
thunder = Spell("Thunder", 12, 120, "black")
blizzard = Spell("Blizzard", 11, 110, "black")
meteor = Spell("Meteor", 15, 150, "black")
quake = Spell("Quake", 15, 150, "black")

# white magic

cure = Spell("Cure", 15, 100, "white")
cura = Spell("Cura", 10, 80, "white")


# hp, mp, atk, df, magic
player = Person(500, 65, 50, 40, [fire, thunder, blizzard, meteor, quake, cure, cura])
enemy = Person(1200, 40, 30, 30, [fire, thunder, blizzard, meteor, quake])


print(bColors.FAIL + bColors.BOLD + "AN ENEMY ATTACKS!!!" + bColors.ENDC)

running = True

while running:
    print("*********************************")
    player.choose_actions()
    choice = input("Enter your Choice: ")
    index = int(choice) - 1
    print("You Chose:", player.get_action(index))

    if index == 0:
        dmg = player.generate_damage()
        enemy.take_damage(dmg)
        print(bColors.OKGREEN + "You attacked for", dmg, "points of damage,", "Enemy Health remaining:",
              str(enemy.get_hp()) + "/" + str(enemy.get_max_hp()) + bColors.ENDC)

    elif index == 1:
        player.choose_spell()
        magic_choice = int(input("Enter your Choice: ")) - 1

        # Get the magic object based on the choice
        player_spell = player.get_magic(magic_choice)

        # Retrieve Name of Magic using Magic object
        spellName = player_spell.get_spell_name()

        # Retrieve Cost of Magic using Magic object
        cost = player_spell.get_spell_mp_cost()
        magic_points = player.get_mp()

        if magic_points < cost:
            print(bColors.OKBLUE + bColors.BOLD + "You do not have sufficient Magic Points to use",
                  bColors.ENDC, spellName + "\n")
            continue
        else:
            player.reduce_mp(cost)
            print("You Chose:", spellName)
            print("You used", cost, ", magic points remaining:", bColors.FAIL +
                  str(player.get_mp()) + "/" + str(player.get_max_mp()) + bColors.ENDC)
            dmg = player_spell.generate_damage()
            enemy.take_damage(dmg)
            print(bColors.OKGREEN + "You attacked for", dmg, "points of damage,", "Enemy Health remaining:",
                  str(enemy.get_hp()) + "/" + str(enemy.get_max_hp()) + bColors.ENDC)

    enemy_choice = random.randrange(2)
    print("Enemy Chose:", enemy.get_action(enemy_choice))
    if enemy_choice == 0:
        dmg = enemy.generate_damage()
        player.take_damage(dmg)
        print(bColors.FAIL + "Enemy attacked for", dmg, "points of damage, Player health remaining:",
              str(player.get_hp()) + "/" + str(player.get_max_hp()) + bColors.ENDC)

    elif enemy_choice == 1:
        enemy_spell_choice = random.randrange(6)

        # Get the magic object based on the choice
        enemy_spell = enemy.get_magic(enemy_spell_choice)

        # Retrieve Name of Magic using Magic object
        enemy_spellName = enemy_spell.get_spell_name()

        # Retrieve Cost of Magic using Magic object
        enemy_cost = enemy_spell.get_spell_mp_cost()

        enemy_magic_points = enemy.get_mp()

        if enemy_magic_points < enemy_cost:
            print(bColors.OKBLUE + bColors.BOLD + "Enemy cannot choose", enemy_spellName,
                  "due to insufficient magic points", bColors.ENDC + "\n")
        else:
            enemy.reduce_mp(enemy_cost)
            print("Enemy Chose Magic Type:", enemy_spellName)
            print("Enemy used", enemy_cost, ", magic points remaining:",
                  str(enemy.get_mp()) + "/" + str(enemy.get_max_mp()))
            dmg = enemy_spell.generate_damage()
            player.take_damage(dmg)
            print(bColors.FAIL + "Enemy attacked for", dmg, "points of damage, Player health remaining:",
                  str(player.get_hp()) + "/" + str(player.get_max_hp()) + bColors.ENDC)

    if enemy.get_hp() == 0:
        print("Game Over! You Won")
        running = False
    elif player.get_hp() == 0:
        print("Gave Over! Enemy Won")
        running = False

