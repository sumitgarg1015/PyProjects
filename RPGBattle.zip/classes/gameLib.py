import random


class bColors:

    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


class Person:

    def __init__(self, hp, mp, atk, df, magic):
        self.hp = hp
        self.maxHp = hp
        self.mp = mp
        self.maxMp = mp
        self.atkL = atk - 10
        self.atkH = atk + 10
        self.df = df
        self.magic = magic
        self.actions = ["Attack", "Magic"]

    def generate_damage(self):
        return random.randrange(self.atkL, self.atkH)

    def take_damage(self, dmg):
        self.hp -= dmg
        if self.hp < 0:
            self.hp = 0
        return self.hp

    def get_magic(self, i):
        return self.magic[i]

    def get_hp(self):
        return self.hp

    def get_max_hp(self):
        return self.maxHp

    def get_mp(self):
        return self.mp

    def get_max_mp(self):
        return self.maxMp

    def reduce_mp(self, cost):
        self.mp -= cost

    def get_action(self, i):
        return self.actions[i]

    def choose_actions(self):
        i = 1
        print("Actions")
        for item in self.actions:
            print(str(i), ":", item)
            i += 1

    def choose_spell(self):
        i = 1
        print("Spells")
        for spell in self.magic:
            print(str(i), ":", spell.get_spell_name(), " (Cost=" + str(spell.get_spell_mp_cost()) + ")")
            i += 1
