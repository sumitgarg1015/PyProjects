import random


class Spell:

    def __init__(self, _name, _cost, _dmg, _mtype):
        self._name = _name
        self._cost = _cost
        self._dmg = _dmg
        self._mType = _mtype

    def get_spell_name(self):
        return self._name

    def get_spell_mp_cost(self):
        return self._cost

    def generate_damage(self):
        dLow = self._dmg - 20
        dHigh = self._dmg + 20
        return random.randrange(dLow, dHigh)

    def get_magic_type(self):
        return self._mType
